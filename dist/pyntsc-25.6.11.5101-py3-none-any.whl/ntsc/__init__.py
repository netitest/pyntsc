from pyntsc.ntsc import *

TYPE_2_OBJECT = {
    "createproject": pyntsc.ntsc.CreateProject,
    "testcase": pyntsc.ntsc.TestCase,
}
